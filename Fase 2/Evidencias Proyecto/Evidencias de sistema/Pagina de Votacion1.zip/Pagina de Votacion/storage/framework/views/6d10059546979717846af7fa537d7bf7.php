<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Votación</h2>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('voto.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="sigla">Sigla</label>
            <select name="sigla" class="form-control" required>
                <?php $__currentLoopData = $votaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $votacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($votacion->sigla); ?>"><?php echo e($votacion->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="opcion_votada">Seleccione una opción</label>
            <select name="opcion_votada" class="form-control" required>
                <option value="opc_1">Opción 1</option>
                <option value="opc_2">Opción 2</option>
                <option value="opc_3">Opción 3</option>
                <option value="opc_4">Opción 4</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Votar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PTY4614-Equipo1\Fase 2\Evidencias Proyecto\Evidencias de sistema\Pagina de Votacion\resources\views/dashboard.blade.php ENDPATH**/ ?>