<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <!-- Header -->
    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content">
        <strong>Tema de la Votaci&oacute;n: <?php echo e($votacion->NOMBRE); ?></strong>
        <div class="sec-head">
            <div class="section sec1">
                <div class="sec1-a">
                    <canvas id="graficoBarras" style="width: 100%; max-height: 300px auto;"></canvas>
                </div>
                <div class="sec1-b">
                    <canvas id="graficoPie" style="width: 100%; max-height: 300px;"></canvas>
                </div>
            </div> 
         
            <div class="section sec2">
                <div class="section-a">
                    <strong>Información Adicional</strong>
                    <p>
                        <?php echo e($votacion->DESCRIPCION); ?> 
                    </p>
                    <div class="fechas">
                    <?php if($votacion->ESTADO == 0): ?>
                        <p>Fecha de inicio: <?php echo e(\Carbon\Carbon::parse($votacion->created_at)->format('d-m-Y')); ?> </p>
                        <p>Fecha de Termino: <?php echo e(\Carbon\Carbon::parse($votacion->updated_at)->format('d-m-Y')); ?> </p>
                        <?php else: ?>
                            <p>Fecha de inicio: <?php echo e(\Carbon\Carbon::parse($votacion->created_at)->format('d-m-Y')); ?> </p>
                    <?php endif; ?>
                    </div>
                </div>
                <strong>Listado de participantes</strong>
                <div class="tabla-content">
                    <table class="section-b table-secondary">
                        <thead>
                            <tr>
                                <th>Opción 1</th>
                                <th>Opción 2</th>
                                <th>Opción 3</th>
                                <th>Opción 4</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i = 0; $i < $maxRows; $i++): ?>
                                <tr>
                                    <td><?php echo e($nombresOP1[$i] ?? ''); ?></td>
                                    <td><?php echo e($nombresOP2[$i] ?? ''); ?></td>
                                    <td><?php echo e($nombresOP3[$i] ?? ''); ?></td>
                                    <td><?php echo e($nombresOP4[$i] ?? ''); ?></td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                <div class="tabla-content">
                    <table class="section-b table-secondary">
                        <thead>
                            <tr>
                                <th>Consejeros Sin Votar</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $sinVotar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="td-noVoto">
                                        <li><?php echo e($usuario); ?></li>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>  
        </div>
        <div class="buttons">
            <?php if($votacion->ESTADO == 1): ?>
                <a href="<?php echo e(route('admin.ae-votaciones-activas')); ?>">Volver</a>
                <form action="<?php echo e(route('admin.finalizar-votacion', $votacion->SIGLA)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas finalizar la votación?');">
                    <?php echo csrf_field(); ?>
                    <label for="opc_ganadora" class="text-gray-700">Selecciona la opción ganadora:</label>
                    <select id="opc_ganadora" name="opc_ganadora" required class="border-gray-300 rounded-md">
                        <option value="">Seleccione una opción </option>
                        <?php if(!empty($votacion->OPC_1)): ?>
                            <option value="<?php echo e($votacion->OPC_1); ?>"><?php echo e($votacion->OPC_1); ?></option>
                        <?php endif; ?>

                        <?php if(!empty($votacion->OPC_2)): ?>
                            <option value="<?php echo e($votacion->OPC_2); ?>"><?php echo e($votacion->OPC_2); ?></option>
                        <?php endif; ?>

                        <?php if(!empty($votacion->OPC_3)): ?>
                            <option value="<?php echo e($votacion->OPC_3); ?>"><?php echo e($votacion->OPC_3); ?></option>
                        <?php endif; ?>

                        <?php if(!empty($votacion->OPC_4)): ?>
                            <option value="<?php echo e($votacion->OPC_4); ?>"><?php echo e($votacion->OPC_4); ?></option>
                        <?php endif; ?>
                    </select>
                    <button class="finalizar" type="submit">Finalizar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('admin.ae-historial-votaciones')); ?>">Volver</a>
                <label for="opc_ganadora" class="text-gray-700"><strong>Opcion Ganadora: <?php echo e($votacion->GANADOR); ?></strong></label>
            <?php endif; ?>
        </div>
    </div>

    <style>
        .content {
            padding: 20px;
            margin: 20px;
            border: solid #000;
            border-radius: 10px;
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align:center;
        }

        @media (max-width: 600px) {  
            .content {
                padding: 20px;
                margin: 20px;
                border: none;
                border-radius: 10px;
                background-color: #ffffff;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                text-align:center;
            }
        }


        .content>strong{
            font-size: 30px;
        }

        .sec-head{
            display: flex;
            /* justify-content: space-around; */
            /* flex-wrap: wrap; */
            justify-content: space-between; 
        }

        .buttons{
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 12px 20px 2px;
        }

        .buttons>a{
            background-color: #FFBD58;
            color: white;
            padding: 8px 20px;
            border-radius: 10px;
        }

        .buttons>form>button{
            background-color: #FFBD58;
            color: white;
            padding: 8px 20px;
            border-radius: 10px;
        }

        .buttons>a:hover{
            background-color: #cc9634; 
            transform: translateY(0); 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .buttons>form>button:hover{
            background-color: #cc9634; 
            transform: translateY(0); 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .sec2>strong{
            font-size: 22px;
        }

        .section {
            /* width: 48%; */
            width: calc(50% - 20px); 
            margin: 10px;
            padding: 20px;
            background-color: #F1F1F1;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }
        .sec1{
            display: flex;
            justify-content: center;
            height: 400px auto;
        }

        .sec1-a, .sec1-b {
            margin: 10px;
            padding: 20px;
            background-color: #F1F1F1;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }
        .section-a {
            padding: 20px;
            margin: 10px 0;
            border: solid #000;
            border-radius: 10px;
            overflow-x: auto;
        }

         .section-b {
            /* padding: 20px; */
            margin: 10px 0;
            overflow-x: auto;
        }

        .section-a {
            background-color: #9abfd781;
        }

        .section-a>strong{
            font-size: 24px;
        }
        .tabla-content{
            height:250px;
            overflow-x: auto;
            margin-top: 15px;
            border: solid #ddd;
            border-radius: 8px;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }
        
        th {
            background-color: #4CAF50;
            color: white;
            padding: 12px;
            border-bottom: 2px solid #ddd;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        .td-noVoto{
            text-align: left;
            padding: ;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .buttons{
            display: flex;
            justify-content: space-between;

        }
        .fechas{
            font-size: 18px;
            padding-right: 5px;
            display: flex;
            justify-content: space-around;
        }

        @media (max-width: 768px) {
            .section {
                width: 100%; 
            }

            .sec-head {
                flex-direction: column;
            }

            .buttons > a, .buttons > form > button {
                margin: 10px 0;
            }
        }

    </style>

    <script>
        const barra = document.getElementById('graficoBarras').getContext('2d');

        const graficoBarras = new Chart(barra, {
            type: 'bar',
            data: {
                labels: [
                    '<?php echo e($votacion->OPC_1); ?> (<?php echo e($countOP1); ?>)',
                    '<?php echo e($votacion->OPC_2); ?> (<?php echo e($countOP2); ?>)',
                    '<?php echo e($votacion->OPC_3); ?> (<?php echo e($countOP3); ?>)',
                    '<?php echo e($votacion->OPC_4); ?> (<?php echo e($countOP4); ?>)'
                ],
                datasets: [
                    {
                        label: 'Votos',
                        data: [<?php echo e($countOP1); ?>, <?php echo e($countOP2); ?>, <?php echo e($countOP3); ?>, <?php echo e($countOP4); ?>],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',  // Color para OPC_1
                            'rgba(54, 162, 235, 0.2)',  // Color para OPC_2
                            'rgba(255, 206, 86, 0.2)',  // Color para OPC_3
                            'rgba(75, 192, 192, 0.2)'   // Color para OPC_4
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',    // Color para OPC_1
                            'rgba(54, 162, 235, 1)',    // Color para OPC_2
                            'rgba(255, 206, 86, 1)',    // Color para OPC_3
                            'rgba(75, 192, 192, 1)'     // Color para OPC_4
                        ],
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true, 
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const pie = document.getElementById('graficoPie').getContext('2d');

        const graficoPie = new Chart(pie, {
            type: 'pie',
            data: {
                labels: [
                    'Personas que no han votado (<?php echo e($usuarioSinVotar); ?>)',
                    'Personas que han votado (<?php echo e($maxRows); ?>)'
                ],
                datasets: [
                    {
                        label: 'Votos',
                        data: [<?php echo e($usuarioSinVotar); ?>, <?php echo e($maxRows); ?>],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',  // Color para OPC_1
                            'rgba(54, 162, 235, 0.2)',  // Color para OPC_2
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',    // Color para OPC_1
                            'rgba(54, 162, 235, 1)',    // Color para OPC_2
                        ],
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true, 
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top', // Posición de la leyenda
                    },
                    title: {
                        display: true,
                        text: 'Votos de Consejeros' // Título del gráfico
                    },
                },
            }
        });
    </script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\PTY4614-Equipo1\Fase 2\Evidencias Proyecto\Evidencias de sistema\Pagina de Votacion\resources\views/admin/ae-detalles-votacion.blade.php ENDPATH**/ ?>