
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Notificación de Votación</title>
</head>
<body>
    <h1>Notificación de Votación</h1>
    <p>Acción: <?php echo e($accion); ?></p> <!-- Agregar esta línea para depuración -->
    <?php if($accion == 'crear'): ?>
        <p>Se ha creado una nueva votación con la sigla <strong><?php echo e($sigla); ?></strong>.</p>
    <?php elseif($accion == 'eliminar'): ?>
        <p>Se ha eliminado la votación con la sigla <strong><?php echo e($sigla); ?></strong>.</p>
    <?php else: ?>
        <p>No se ha definido ninguna acción.</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PTY4614-Equipo1\Pagina de Votacion\resources\views/emails/emailsvotacion.blade.php ENDPATH**/ ?>