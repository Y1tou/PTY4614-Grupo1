<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
    <title>Consejeros Home</title>
</head>

<body>
    <?php echo $__env->make('consejero.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content">
        <!-- Links -->
        <?php echo $__env->make('consejero.partials.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Votaciones disponibles -->
        <main id="miMain" class="p-6 flex-grow">
            <h1 class="text-2xl font-bold mb-6">Lista de Votaciones Disponibles</h1>
            <?php $__currentLoopData = $votacionesConVotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="space-y-6  card-voto">
                    <form class="bg-white shadow-md rounded p-4 border" action="<?php echo e(route('voto.store')); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de la opción seleccionada?');">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="sigla" value="<?php echo e($voto->SIGLA); ?>">

                        <div class="flex justify-between items-center">
                            <div class="font-bold text-xl">Tema de la Votación: <?php echo e($voto->NOMBRE); ?></div>
                            <div class="text-gray-600">Fecha Inicio: <?php echo e(\Carbon\Carbon::parse($voto->created_at)->format('d-m-Y')); ?></div>
                        </div>
                        <p class="text-gray-700 my-4">Descripción: <?php echo e($voto->DESCRIPCION); ?></p>
                        <?php if($voto->voto_realizado): ?>
                            <div class="flex items-center space-x-4">
                                <label class="text-gray-700">Opción Seleccionada:</label>
                                <span class="text-gray-700"><?php echo e($voto->opcion_votada); ?></span>
                            </div>
                        <?php else: ?>
                            <div class="flex items-center space-x-4">
                                <label for="opcion_votada" class="text-gray-700">Selecciona una opción:</label>
                                <select id="opcion_votada" name="opcion_votada" required class="border-gray-300 rounded-md">
                                    <option value="">Seleccione una opción</option>
                                    <?php if(!empty($voto->OPC_1)): ?>
                                        <option value="<?php echo e($voto->OPC_1); ?>"><?php echo e($voto->OPC_1); ?></option>
                                    <?php endif; ?>

                                    <?php if(!empty($voto->OPC_2)): ?>
                                        <option value="<?php echo e($voto->OPC_2); ?>"><?php echo e($voto->OPC_2); ?></option>
                                    <?php endif; ?>

                                    <?php if(!empty($voto->OPC_3)): ?>
                                        <option value="<?php echo e($voto->OPC_3); ?>"><?php echo e($voto->OPC_3); ?></option>
                                    <?php endif; ?>

                                    <?php if(!empty($voto->OPC_4)): ?>
                                        <option value="<?php echo e($voto->OPC_4); ?>"><?php echo e($voto->OPC_4); ?></option>
                                    <?php endif; ?>
                                </select>
                                <button type="submit" class="bg-blue-800 text-white px-4 py-1 rounded">Confirmar voto</button>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
        
        <?php if(session('success')): ?>
                <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                    <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
                        <h2 class="text-2xl font-semibold mb-4 text-green-600">¡Éxito!</h2>
                        <p class="mb-4"><?php echo e(session('success')); ?></p>
                        <button onclick="closeModal()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Cerrar</button>
                    </div>
                </div>
            <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
                    <h2 class="text-2xl font-semibold mb-4 text-red-600">Mensaje</h2>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="mb-4"><li><?php echo e($error); ?></li></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button onclick="closeModal()" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Cerrar</button>
                </div>
            </div>
            <?php elseif(session('error')): ?>
            <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
                    <h2 class="text-2xl font-semibold mb-4 text-red-600">Mensaje</h2>
                        <p class="mb-4">
                            <li>Ocurrió un problema al enviar el voto. Por favor, inténtalo de nuevo</li>
                        </p>
                    <button onclick="closeModal()" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Cerrar</button>
                </div>
            </div>
            <?php elseif(session('noValido')): ?>
            <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full text-center">
                    <h2 class="text-2xl font-semibold mb-4 text-red-600">Mensaje</h2>
                        <p class="mb-4">
                            <li><?php echo e(session('noValido')); ?></li>
                        </p>
                    <button onclick="closeModal()" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Cerrar</button>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>


<style>

    body{
        background-color: #F1F1F1;
    }

    .content {
        height: 100%;
        width: 100%;
        background-color: #F1F1F1;
        display: flex;
        justify-content: center;
    }

    .card-voto{
        margin: 10px 0;
    }

    .sec2 {
        height: 60%;
        width: 100%;
        margin: 5%;
        padding: 2% 5%;
        border-radius: 10px;
        border: solid #000;
        display: flex;
        justify-content: center;
        flex-direction: column;
        background-color: #F1F1F1;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    input,
    select {
        width: 100%;
        padding: 10px 10px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
        font-size: 20px;
    }

    .sec2>button {
        background-color: #FFFFFF;
        color: #000;
        padding: 14px 20px;
        margin: 25px 0;
        border-radius: 10px;
        border-color: #000;
        cursor: pointer;
        width: 100%;
        font-size: 18px;
    }

    .sec2>button:hover {
        background-color: #FFBD58;
        color: #FFFFFF;
    }

    @media (max-width: 600px) {
        select {
            font-size: 16px; /* Ajusta el tamaño de la fuente */
            padding: 8px; /* Ajusta el padding para reducir el tamaño en móviles */
        }
        select option {
            font-size: 16px; /* Ajusta el tamaño de la fuente de las opciones */
        }
    }

</style>


<script>
    function handleResize() {
        const mainElement = document.getElementById('miMain');

        if (window.matchMedia('(max-width: 600px)').matches) {
            // Si la pantalla es menor o igual a 600px, quita la clase sec2
            mainElement.classList.remove('sec2');
        } else {
            // Si la pantalla es mayor a 600px, añade la clase sec2
            mainElement.classList.add('sec2');
        }
    }

    // Agregar el evento de resize
    window.addEventListener('resize', handleResize);

    // Llamar la función al cargar la página
    handleResize();

    // Mensaje 
    function closeModal() {
    document.querySelector('.fixed').style.display = 'none';
    }
</script><?php /**PATH C:\xampp\htdocs\PTY4614-Equipo1\Fase 2\Evidencias Proyecto\Evidencias de sistema\Pagina de Votacion\resources\views/consejero/home.blade.php ENDPATH**/ ?>